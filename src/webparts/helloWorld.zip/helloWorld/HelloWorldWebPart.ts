import { Version } from '@microsoft/sp-core-library';
import {
  IPropertyPaneConfiguration,
  PropertyPaneTextField
} from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart } from '@microsoft/sp-webpart-base';
import { IReadonlyTheme } from '@microsoft/sp-component-base';
import * as strings from 'HelloWorldWebPartStrings';
import { SPComponentLoader } from '@microsoft/sp-loader';

export interface IHelloWorldWebPartProps {
  description: string;
}

export default class HelloWorldWebPart extends BaseClientSideWebPart<IHelloWorldWebPartProps> {


  public render(): void {
    this.domElement.innerHTML = `
    <section>
        <div class="container">
          <div class="box level-1">
            <a href="#">
              <ul>
                <h1>Directie</h1>
                <li>Jeroen de bonth</li>
              </ul>
            </a>
          </div>
          <ol class="level-2-wrapper">
            <li>
              <section class="box2 level-5">
                <a href="https://vitsolutionseu.sharepoint.com/sites/Marketing" target="_blank">
                  <ul>
                    <h1>Marketing</h1>
                    <li>Suzan Doreglo</li>
                    <li>Linda Goesten</li>
                  </ul>
                </a>
              </section>
            </li>
            <li>
              <section class="box2 level-2 rectangle">
                <a href="https://vitsolutionseu.sharepoint.com/sites/FinanceControle" target="_blank">
                  <ul>
                    <h1>Finance & Controle</h1>
                    <li>Patrice Riebergen</li>
                    <li>sander vreugdenhil</li>
                    <li>Jan van Son</li>
                  </ul>
                </a>
              </section>
              <ol class="level-3-wrapper">
                <li>
                  <section class="level-3 rectangle">
                    <a href="#">
                      <ul>
                        <h3>Finaciel Admin</h3>
                        <li>Doin van rooij</li>
                      </ul>
                    </a>
                  </section>
                </li>
                <li>
                  <section class="level-3 rectangle">
                    <a href="#">
                      <ul>
                        <h3>Projectcontrol</h3>
                        <li>Sjoerd de bonth</li>
                        <li>Jurre Scheij</li>
                      </ul>
                    </a>
                  </section>
                </li>
              </ol>
            </li>
          </ol>
          <ol class="level-6-wrapper">
            <li>
              <section class="box2 level-5">
                <a href="https://vitsolutionseu.sharepoint.com/sites/Receptie" target="_blank">
                  <ul>
                    <h1>Receptie</h1>
                    <li>Roby Oerlemans</li>
                    <li>Marjan de Man 1/9</li>
                  </ul>
                </a>
              </section>
            </li>
          </ol>
          <ol class="level-7-wrapper">
            <li>
              <section class="box2 level-5">
                <a href="https://vitsolutionseu.sharepoint.com/sites/KAM" target="_blank">
                  <ul>
                    <h1>KAM</h1>
                    <li>Casper Goossen</li>
                  </ul>
                </a>
              </section>
            </li>
            <li>
              <section class="box2 level-5">
                <a href="https://vitsolutionseu.sharepoint.com/sites/HRIT" target="_blank">
                  <ul>
                    <h1>HR/IT</h1>
                    <li>Geronimo Lambertus</li>
                  </ul>
                </a>
              </section>
            </li>
          </ol>
      </div>
    </section>`;
  }

  protected onInit(): Promise<void> {
    SPComponentLoader.loadCss('/sites/Seco/SiteAssets/style.css'); return super.onInit();
  }



  // private _getEnvironmentMessage(): Promise<string> {
  //   if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
  //     return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
  //       .then(context => {
  //         let environmentMessage: string = '';
  //         switch (context.app.host.name) {
  //           case 'Office': // running in Office
  //             environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOffice : strings.AppOfficeEnvironment;
  //             break;
  //           case 'Outlook': // running in Outlook
  //             environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentOutlook : strings.AppOutlookEnvironment;
  //             break;
  //           case 'Teams': // running in Teams
  //             environmentMessage = this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentTeams : strings.AppTeamsTabEnvironment;
  //             break;
  //           default:
  //             throw new Error('Unknown host');
  //         }

  //         return environmentMessage;
  //       });
  //   }

  //   return Promise.resolve(this.context.isServedFromLocalhost ? strings.AppLocalEnvironmentSharePoint : strings.AppSharePointEnvironment);
  // }

  protected onThemeChanged(currentTheme: IReadonlyTheme | undefined): void {
    if (!currentTheme) {
      return;
    }

    // this._isDarkTheme = !!currentTheme.isInverted;
    const {
      semanticColors
    } = currentTheme;

    if (semanticColors) {
      this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
      this.domElement.style.setProperty('--link', semanticColors.link || null);
      this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
    }

  }

  protected get dataVersion(): Version {
    return Version.parse('1.0');
  }

  protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration {
    return {
      pages: [
        {
          header: {
            description: strings.PropertyPaneDescription
          },
          groups: [
            {
              groupName: strings.BasicGroupName,
              groupFields: [
                PropertyPaneTextField('description', {
                  label: strings.DescriptionFieldLabel
                })
              ]
            }
          ]
        }
      ]
    };
  }
}
