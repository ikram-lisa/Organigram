/* tslint:disable */
require("./HelloWorldWebPart.module.css");
const styles = {
  helloWorld: 'helloWorld_85892f1a',
  teams: 'teams_85892f1a',
  welcome: 'welcome_85892f1a',
  welcomeImage: 'welcomeImage_85892f1a',
  links: 'links_85892f1a',
  test: 'test_85892f1a'
};

export default styles;
/* tslint:enable */